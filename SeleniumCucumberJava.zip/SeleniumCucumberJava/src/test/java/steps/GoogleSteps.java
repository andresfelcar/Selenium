package steps;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GoogleSteps {

    @Given("^navego a google$")

    public void navigateToGoogle() {
    }

    @When("^busco algo$")

    public void enterSearchCriteria() {
    }

    @And("^click en el boton buscar$")

    public void clickSearchButton() {
    }

    @Then("^obtengo resultados$")

    public void validateResults() {
    }

    
}
